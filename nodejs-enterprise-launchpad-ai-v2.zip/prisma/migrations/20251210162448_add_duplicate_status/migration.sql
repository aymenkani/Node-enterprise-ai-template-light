-- AlterEnum
ALTER TYPE "FileStatus" ADD VALUE 'DUPLICATE';
